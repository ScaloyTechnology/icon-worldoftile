export const SITE_LOADER_COMPLETE_EVENT = "icon:site-loader-complete";
export const PAGE_ASSETS_READY_EVENT = "icon:page-assets-ready";
export const MOTION_READY_EVENT = "icon:motion-ready";
export const CRITICAL_ASSET_READY_EVENT = "icon:critical-asset-ready";

export function markPageAssetsReady(pathname: string) {
  document.documentElement.dataset.iconAssetsPath = pathname;
  window.dispatchEvent(new CustomEvent(PAGE_ASSETS_READY_EVENT, { detail: { pathname } }));
}

export function waitForPageAssets(pathname: string, signal: AbortSignal) {
  if (signal.aborted || document.documentElement.dataset.iconAssetsPath === pathname) return Promise.resolve();
  return new Promise<void>(resolve => {
    const complete = () => {
      window.removeEventListener(PAGE_ASSETS_READY_EVENT, ready);
      signal.removeEventListener("abort", complete);
      resolve();
    };
    const ready = (event: Event) => {
      if ((event as CustomEvent<{ pathname: string }>).detail?.pathname === pathname) complete();
    };
    window.addEventListener(PAGE_ASSETS_READY_EVENT, ready);
    signal.addEventListener("abort", complete, { once: true });
  });
}

export function resetMotionReady() {
  document.documentElement.removeAttribute("data-icon-motion-ready");
  document.documentElement.removeAttribute("data-icon-motion-path");
}

export function markMotionReady(pathname: string) {
  document.documentElement.setAttribute("data-icon-motion-ready", "true");
  document.documentElement.setAttribute("data-icon-motion-path", pathname);
  window.dispatchEvent(new CustomEvent(MOTION_READY_EVENT, { detail: { pathname } }));
}

export function waitForMotionReady(pathname: string) {
  if (document.documentElement.getAttribute("data-icon-motion-ready") === "true"
    && document.documentElement.getAttribute("data-icon-motion-path") === pathname) return Promise.resolve();

  return new Promise<void>((resolve) => {
    const ready = (event: Event) => {
      const detail = (event as CustomEvent<{ pathname?: string }>).detail;
      if (detail?.pathname !== pathname) return;
      window.removeEventListener(MOTION_READY_EVENT, ready);
      resolve();
    };
    window.addEventListener(MOTION_READY_EVENT, ready);
  });
}

function criticalAttribute(id: string) {
  return `data-icon-ready-${id.replace(/[^a-z0-9-]/gi, "-").toLowerCase()}`;
}

export function resetCriticalAsset(id: string) {
  document.documentElement.removeAttribute(criticalAttribute(id));
}

export function markCriticalAssetReady(id: string) {
  document.documentElement.setAttribute(criticalAttribute(id), "true");
  window.dispatchEvent(new CustomEvent(CRITICAL_ASSET_READY_EVENT, { detail: { id } }));
}

export function waitForCriticalAsset(id: string) {
  if (document.documentElement.getAttribute(criticalAttribute(id)) === "true") return Promise.resolve();
  return new Promise<void>((resolve) => {
    const ready = (event: Event) => {
      if ((event as CustomEvent<{ id?: string }>).detail?.id !== id) return;
      window.removeEventListener(CRITICAL_ASSET_READY_EVENT, ready);
      resolve();
    };
    window.addEventListener(CRITICAL_ASSET_READY_EVENT, ready);
  });
}

export function waitForSiteLoader(signal?: AbortSignal) {
  const loader = document.querySelector<HTMLElement>("[data-site-loader]");
  if (!loader || loader.dataset.state === "hidden" || signal?.aborted) return Promise.resolve();
  return new Promise<void>((resolve) => {
    const complete = () => {
      clearTimeout(deadline);
      window.removeEventListener(SITE_LOADER_COMPLETE_EVENT, complete);
      signal?.removeEventListener("abort", complete);
      resolve();
    };
    const deadline = window.setTimeout(complete, 5500);
    window.addEventListener(SITE_LOADER_COMPLETE_EVENT, complete, { once: true });
    signal?.addEventListener("abort", complete, { once: true });
  });
}
