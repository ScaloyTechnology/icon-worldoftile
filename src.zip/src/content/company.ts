/*
 * Verified client data.
 * Company-profile facts: docs/Company Profile_Updated.pdf (pages noted below).
 * Contact, unit and social data: final client brief dated 2026-09-13; this
 * intentionally overrides the older contact panel on profile page 12.
 */

export const companyContact = {
  domestic: {
    label: "Domestic inquiry",
    phone: "+91 82380 49090",
    phoneHref: "tel:+918238049090",
    email: "inquiry@iconworldoftile.com",
    emailHref: "mailto:inquiry@iconworldoftile.com",
  },
  export: {
    label: "Export inquiry",
    phone: "+91 87587 39191",
    phoneHref: "tel:+918758739191",
    email: "export@iconworldoftile.com",
    emailHref: "mailto:export@iconworldoftile.com",
  },
  units: [
    {
      id: "icon-granito",
      number: "01",
      name: "ICON GRANITO PVT. LTD.",
      addressLines: ["Survey No. 8/14,", "Ghuntu Road,", "Mahendra Nagar,", "Morbi - 363 642,", "Gujarat,", "INDIA"],
      mapUrl: "https://maps.app.goo.gl/Fuu8jivGw3AGs9Jx9",
    },
    {
      id: "acecon-vitrified",
      number: "02",
      name: "ACECON VITRIFIED PVT. LTD.",
      addressLines: ["8-A National Highway,", "Matel Road,", "Matel,", "Ta. Wankaner - 363 621,", "Dist. Morbi,", "Gujarat,", "INDIA"],
      mapUrl: "https://maps.app.goo.gl/pTgzJYJWr4nMnpAH9",
    },
    {
      id: "duracon-vitrified",
      number: "03",
      name: "DURACON VITRIFIED PVT. LTD.",
      addressLines: ["8-A National Highway,", "Sartanpar Road,", "Tal. Wankaner - 363 621,", "Dist. Morbi,", "Gujarat,", "INDIA"],
      mapUrl: "https://maps.app.goo.gl/H4nwNKaFCBqPVU7p7",
    },
  ],
  socials: [
    { label: "Instagram", href: "https://www.instagram.com/iconworldoftile/?hl=en" },
    { label: "Facebook", href: "https://www.facebook.com/pages/Icon%20Granito%20Pvt%20Ltd/130746197621918/" },
    { label: "LinkedIn", href: "https://in.linkedin.com/company/iconworldoftile" },
  ],
} as const;

export const companyProfile = {
  story: {
    sourcePage: 2,
    title: "The story of 38 years",
    statement: "We are a product of choice and style.",
    description: "Our journey in this industry is a passion for exploring unmatched product selection and the reasons behind the best choice of a large market.",
  },
  milestones: [
    {
      year: "1987", name: "SANGHDOOT INDUSTRIES",
      description: "Our journey began in 1987 with the manufacturing of traditional terracotta roofing tiles through Sanghdoot Industries. This marked our foundation in the building materials industry.",
    },
    {
      year: "1990", name: "RAJDOOT CERAMIC INDUSTRIES",
      description: "In 1990, we expanded our roofing tile manufacturing operations by establishing Rajdoot Ceramic Industries as our second production facility, strengthening our manufacturing foundation.",
    },
    {
      year: "1995", name: "EVERSHINE CERA PVT. LTD.",
      description: "1995 marked our entry into ceramic wall tile manufacturing with the establishment of Evershine Cera at Dhuva, Morbi. We became one of the early participants in Morbi's emerging ceramic tile industry.",
    },
    {
      year: "2002", name: "ICON CERAMIC LIMITED",
      description: "In 2002, we established Icon Ceramic Limited at Lalpar, Morbi, expanding our manufacturing capabilities into ceramic floor tiles and broadening our product portfolio beyond roofing and wall tiles.",
    },
    {
      year: "2007", name: "ICON GRANITO PVT. LTD.",
      description: "In 2007, we entered vitrified tile manufacturing with the establishment of Icon Granito Pvt. Ltd. This milestone played a defining role in shaping the identity of ICON World of Tile.",
    },
    {
      year: "2009", name: "AVLON CERAMIC PVT. LTD.",
      description: "In 2009, we established Avlon Ceramic as our second ceramic wall tile manufacturing facility, expanding production into larger wall tile sizes and strengthening our presence in the ceramic industry.",
    },
    {
      year: "2011", name: "DURACON VITRIFIED PVT. LTD.",
      description: "In 2011, we established Duracon Vitrified, introducing double-charged vitrified tile manufacturing. Advanced feeder technology enabled us to develop a wider range of patterns and designs.",
    },
    {
      year: "2015", name: "ERACON VITRIFIED PVT. LTD.",
      description: "In 2015, we established Eracon Vitrified, a modern manufacturing facility equipped with Italian SACMI machinery. The plant introduced larger double-charged vitrified tile formats, including 800 × 800 mm and 800 × 1200 mm.",
    },
    {
      year: "2017", name: "ACECON VITRIFIED PVT. LTD.",
      description: "In 2017, we established Acecon Vitrified, one of our most significant manufacturing expansions. Equipped with two kilns, it became the ICON Group's largest manufacturing facility at the time.",
    },
    {
      year: "2025", name: "COMMENCEMENT OF SLAB PRODUCTION",
      description: "In 2025, we expanded our Acecon manufacturing facility to begin large-format slab production, introducing new possibilities in architectural surfaces and large-format tile applications.",
    },
    {
      year: "2026", name: "AVLON — TILING SOLUTIONS",
      description: "In 2026, we expanded our Avlon facility into tile adhesives, grouts and tiling solutions, extending the ICON product portfolio beyond tiles to support installation and finishing applications.",
    },
  ],
  pillars: [
    { title: "IDEATE INNOVATE", description: "Where imagination begins. Crafting concepts shaped by nature, refined by design." },
    { title: "INSPIRE", description: "Advancing surfaces through new textures, techniques, and thinking. Innovation that transforms possibilities into products." },
    { title: "RISE WITH INTEGRITY", description: "Setting benchmarks for the industry with pioneering creations. Designs that elevate spaces and spark new ideas." },
  ],
  sustainability: [
    {
      title: "Natural Gas Powered Kiln for Reduced Emissions",
      description: "Advanced kilns powered by natural gas reduce harmful emissions compared with conventional fuels while maintaining precise temperature control for consistent tile quality and durability.",
    },
    {
      title: "Solar Energy Integration in Production",
      description: "Solar power supports approximately 33% of total production energy requirements, reducing dependence on non-renewable resources and lowering carbon emissions.",
      metric: "Approximately 33%",
    },
    {
      title: "100% Recycled Packaging",
      description: "Packaging materials are designed around a fully recycled approach, reducing virgin material use while protecting every surface through storage and transit.",
      metric: "100%",
    },
    {
      title: "Zero Liquid Discharge Plant",
      description: "Process water is recovered, treated and reused within the plant to prevent industrial wastewater discharge and support responsible water management.",
      metric: "Zero discharge",
    },
  ],
  infrastructure: {
    description: "At ICON, our modernized and well-furnished infrastructure unit supports our team-mates in the production process of our complete variety of qualitative tile products within an assured span of time.",
    statements: ["State of the art infrastructure", "One of the largest plant in India", "Network in more than 60 countries", "Fastest growing ceramic brand in India"],
    stats: [
      { value: "1500+", label: "Tiles Design", sourcePage: 5 },
      { value: "30+", label: "Year experience", sourcePage: 5 },
      { value: "300+", label: "Dealers Worldwide", sourcePage: 5 },
      { value: "1,00,000 sq. mtr. per day", label: "Production Capacity", sourcePage: 5 },
      { value: "15+", label: "World Class Design Developer & R & D Highly Quality & Skilled In-house Team", sourcePage: 5 },
    ],
  },
  technologies: [
    { name: "SACMI", role: "Forming & firing", description: "We utilize SACMI presses and kilns for forming and firing our tiles, ensuring high-density and strength." },
    { name: "APPEL", role: "Quality analysis", description: "We employ advanced APPEL planar machines for sophisticated tile quality analysis and precise sorting." },
    { name: "LB", role: "Color body technology", description: "Our color body technology uses LB color machines to create consistent and deep colors throughout the tile." },
    { name: "SYSTEM CERAMICS", role: "Digital decoration", description: "We use SYSTEM CERAMICS' high-DPI printing digital machines for accurate and vibrant tile decoration." },
    { name: "CONTINUA+", role: "Continuous forming", description: "We integrate the latest CONTINUA+ press technology for continuous forming and production efficiency." },
    { name: "CREAVISION", role: "Double digital synchronizing", description: "We leverage CREAVISION for double digital synchronizing to optimize flow and elevate printing quality." },
  ],
  qualityControls: [
    "Creavision & barcode technology",
    "Continua plus",
    "High dpi printing digital machine",
    "Proper infrastructure to produce technical vitrified tile",
    "Stringent Quality norms as per european standards",
    "Audited certifications",
  ],
  certificationMarks: ["CE", "ISO 9001:2015", "UKCA", "IS 15622 / CML-7900142414"],
  innovation: {
    title: "First in industry",
    description: "Double Digital Technology powered by System and Creavision creates a unique texture for every individual slab. Creavision tracking aligns design and texture, while selected accents and a premium Dry Granilla top coat give iSparkle tiles a high-gloss, mirror finish.",
    marks: ["Double Sync", "iSparkle", "Impressions"],
  },
  natureInspired: {
    title: "Nature inspired",
    description: "Nature is our greatest source of inspiration. We study marble, stone, wood and concrete, then use advanced digital and surface technologies to capture their depth, realism and detail in engineered surfaces.",
  },
  manufacturingProcess: ["Incoming Raw Material", "Raw Material Inspection", "Godown", "Ball Mill Mixing", "Slurry", "Spray Dryer", "Pressing", "Dryer", "Glazing", "Printing", "Heating", "Polishing", "Sizing", "Sorting", "Packing", "Ware House", "Dispatch"],
  surfaces: ["MATT", "POLISHED", "HIGH GLOSS", "SILK", "HONED", "CRAVING", "POLISHED GLIMMER", "METALLIC", "R & R11", "iSparkle", "iShape+", "iSheen", "PIXEL", "iShape Glitter", "GHR", "GRANILLA", "iGlam", "iGraffiti", "MAGIC", "iLuxury"],
  sizes: ["80 × 320 cm", "80 × 300 cm", "60 × 120 cm", "45 × 90 cm", "60 × 60 cm", "80 × 240 cm", "20 × 20 cm", "30 × 30 cm", "80 × 160 cm", "80 × 80 cm", "30 × 60 cm", "120 × 240 cm", "20 × 120 cm", "120 × 180 cm", "120 × 280 cm", "120 × 120 cm", "29.8 × 60 cm", "29.8 × 29.8 cm"],
  markets: [
    "Australia", "Bahrain", "Barbados", "Belarus", "Belgium", "Bolivia", "Bosnia", "Brazil", "Bulgaria", "Cameroun", "Canada", "Chile", "Colombia", "Croatia", "Cyprus", "Dominican Republic",
    "Ecuador", "El Salvador", "France", "Georgia", "Germany", "Greece", "Guatemala", "Honduras", "India", "Iraq", "Ireland", "Italy", "Jamaica", "Kazakhstan", "Kenya", "Kosovo",
    "Kuwait", "Lebanon", "Leicestershire", "Malta", "Mauritius", "Mexico", "Moldova", "Morocco", "Netherlands", "New Zealand", "Nepal", "Oman", "Peru", "Poland", "Puerto Rico", "Qatar",
    "Romania", "Russia", "Seychelles", "South Korea", "Spain", "Taiwan", "Thailand", "Trinidad And Tobago", "Turkey", "UAE", "UK", "Uruguay", "USA", "Uzbekistan", "Venezuela", "Vietnam",
  ],
  suppliers: ["Vidres India", "Colorobbia", "Torrecid", "Esmalglass-Itaca Grupo", "Icer Italian Ceramic Surfaces", "Zschimmer & Schwarz"],
} as const;
