export { default } from "../loading";
